# FlexiT
Mohammed, Refath, Nicole, Cypres

Project: Ever wanted an all-in-one workout app, don't look any further. FlexiT is everything your regular work-out app wishes to be. 


